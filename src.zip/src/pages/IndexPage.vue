<template>
  
   <div class = "info-box">

   <h1> Sanika Salunke</h1>
   <p> Age : 22</p>
   <p> Native : Pune , Maharashtra </p>
   <p> Family : Mother , Father , Younger sister</p>
   <p> Email : sanikasalunke14062001@gmail.com</p>
   <p>LinkedIn : <a href="https://www.linkedin.com/in/sanika-salunke-4019661b6">LinkedIn Profile</a></p>

   </div>

</template>
<style>
body{
   background-image:url("C:/Users/10725909/Downloads/background.jpg");
   background-color:#f0f0f0;
   font-family:Arial, sans-serif;
}
.info-box{
   background-image:url("C:/Users/10725909/Downloads/background.jpg");
   border: 2px solid #472100;
   border-radius:10px;
   padding:20px;
   width:500px;
   margin:0 auto;
   background-color:#ffe7d1;
   
}
h1{
   color:#6d1c1c
}
p{
   color:#472100;
   font-weight: bold;
}
</style>