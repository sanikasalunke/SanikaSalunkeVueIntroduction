<template>
   <div class = "info-box">

      <h1> My Education</h1>
      <img width="80" height="80" src="../assets/education.jpg"/><br><br>
      <p> College : Vishwakarma Institute of Technology , Pune (2019 - 2023 )</p>
      <p> Program : Bachelors of Technology</p>
      <p> Course : Information Technology</p>
      <p> College : Pune Vidyarthi Gruha (2017 - 2019)</p>
      <p> Program : Higher secondary Education</p>
      <p> Course : PCM </p>
      
   </div>

</template>
<style>
   body{
      background-color:#f0f0f0;
      font-family:Arial, sans-serif;
   }
   .info-box{
      border: 2px solid #472100;
      border-radius:10px;
      padding:20px;
      width:500px;
      margin:0 auto;
   
    }
   h1{
      color:#6d1c1c
   }
   p{
      color:#472100;
      font-weight: bold;
   }
</style>