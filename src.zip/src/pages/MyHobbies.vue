<template>
  
   <div class = "info-box">

   <h1> My Hobbies </h1>
   <p> Dance : Hiphop , Bollywood , Contemporary.<br> Recieved awards from Jacky shroff , Amruta Khanwilkar<br>Represented college in Firodiya Karandak(State level) and at MoodIndigo(National level)</p>
   <p> Basketball : Represented my College at State level  </p>
   <img width="150" height="150" src="../assets/dance.jpg" /><img width="150" height="150" src="../assets/Basketball.jpg" />

   </div>

</template>
<style>
body{
   background-color:#f0f0f0;
   font-family:Arial, sans-serif;
}
.info-box{
   border: 2px solid #472100;
   border-radius:10px;
   padding:20px;
   width:500px;
   margin:0 auto;
   
}
h1{
   color:#6d1c1c
}
p{
   color:#472100;
   font-weight: bold;
   }
</style>