<template>
  
   <div class = "info-box">

   <h1> Technical Interests</h1>
   <p> AI ML Datascience NLP Selenium Python </p>
   <p> Geospatial Engineering</p>
   <p> Projects : "Fall Detection using Pose Estimation and Smart Alarming System"</p>

   </div>

</template>
<style>
body{
   background-color:#f0f0f0;
   font-family:Arial, sans-serif;
}
.info-box{
   border: 2px solid #0077b6;
   border-radius:10px;
   padding:20px;
   width:500px;
   margin:0 auto;
   
}
h1{
   color:#0077b6
}
</style>