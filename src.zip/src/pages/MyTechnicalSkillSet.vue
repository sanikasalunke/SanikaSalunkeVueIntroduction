<template>
  
   <div class = "info-box">

   <h1> Technical Interests</h1>
   <p> AI ML Datascience NLP Selenium Python SQL Docker Linux </p>
   <p> Geospatial Engineering > Worked on Geospatial Data while my semester internship at Tomtom</p>
   <p> Research Papers : "YOLOv5 Improved Helmet Detection"<br>"Career Couselling using EEG data and Questionares" (ML)<br></p>
   <p> Projects :<br>"Fall Detection using Pose Estimation and Smart Alarming System : "<br>Movenet , Tensorflow Lite , Twilio Api , Django ,Python<br>
   "OpenStreets Maps Detection : "<br>Osmnx , Machine Learning</p>

   </div>

</template>
<style>
body{
   background-color:#f0f0f0;
   font-family:Arial, sans-serif;
}
.info-box{
   border: 2px solid #472100;
   border-radius:10px;
   padding:20px;
   width:500px;
   margin:0 auto;
   
}
h1{
   color:#6d1c1c
}
p{
   color:#472100;
   font-weight: bold;
   }
</style>